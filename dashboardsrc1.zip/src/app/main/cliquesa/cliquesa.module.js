(function() {
    'use strict';

    angular
        .module('cliquesa', [
        ]);
})();
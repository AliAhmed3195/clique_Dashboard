This directory contains demo data json files.
You can remove this after setting up your own API URLs.
(function() {
    'use strict';

    angular
        .module('quickbooks', [
        ]);
})();
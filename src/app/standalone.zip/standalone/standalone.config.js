(function() {
    'use strict';
    angular
        .module('standalone');
})();